﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LogFileProcessor.UnitTests
{
    [TestClass]
    public class ProcessorTest
    {
        private Dictionary<string, int> IP_count_expect = new Dictionary<string, int>
            {
                { "168.41.191.40", 4 },
                { "72.44.32.10", 3 },
                { "168.41.191.43", 2 },
                { "79.125.00.21", 1 }
            };
        private Dictionary<string, int> URL_count_expect = new Dictionary<string, int>
            {
                { "/download/counter/", 4 },
                { "/blog/category/community/", 3 },
                { "http://example.net/faq/", 1 }
            };
        private readonly string TEST_LOG_ADDRESS = "..\\..\\TestData\\programming-task-example-data-test.log";
        private readonly string ACTUAL_REPORT_ADDRESS = "..\\..\\TestData\\Report-actual.txt";
        private readonly string EXPECT_REPORT_ADDRESS = "..\\..\\TestData\\Report-expect.txt";
        private readonly string EXPECT_OUTPUT = @"Number of Unique IP Address: 4
Top 1 Most Visited URL: /download/counter/ Count: 4
Top 2 Most Visited URL: /blog/category/community/ Count: 3
Top 3 Most Visited URL: http://example.net/faq/ Count: 1
Top 1 Active IP Address: 168.41.191.40 Count: 4
Top 2 Active IP Address: 72.44.32.10 Count: 3
Top 3 Active IP Address: 168.41.191.43 Count: 2";

        private string GetFileHash(string filename)
        {
            var hash = new SHA1Managed();
            var clearBytes = File.ReadAllBytes(filename);
            var hashedBytes = hash.ComputeHash(clearBytes);
            return ConvertBytesToHex(hashedBytes);
        }
        private string ConvertBytesToHex(byte[] bytes)
        {
            var sb = new StringBuilder();

            for (var i = 0; i < bytes.Length; i++)
            {
                sb.Append(bytes[i].ToString("x"));
            }
            return sb.ToString();
        }

        [TestMethod]
        public void ReadLogFileTest()
        {
            Dictionary<string, int> IP_count_actual = new Dictionary<string, int>();
            Dictionary<string, int> URL_count_actual = new Dictionary<string, int>();

            Processor.ReadLogFile(ref IP_count_actual, ref URL_count_actual, TEST_LOG_ADDRESS);

            var IP_count_actual_sorted = IP_count_actual.OrderByDescending(x => x.Value).ToDictionary(x => x.Key, x => x.Value);
            var URL_count_actual_sorted = URL_count_actual.OrderByDescending(x => x.Value).ToDictionary(x => x.Key, x => x.Value);
            var IP_count_expect_sorted = IP_count_expect.OrderByDescending(x => x.Value).ToDictionary(x => x.Key, x => x.Value);
            var URL_count_expect_sorted = URL_count_expect.OrderByDescending(x => x.Value).ToDictionary(x => x.Key, x => x.Value);

            CollectionAssert.AreEqual(IP_count_expect_sorted, IP_count_actual_sorted);
            CollectionAssert.AreEqual(URL_count_expect_sorted, URL_count_actual_sorted);
        }

        [TestMethod]
        public void ProcessLogFileTest()
        {
            var actualOutput = Processor.ProcessLogFile(IP_count_expect, URL_count_expect, 3);
            Assert.AreEqual(EXPECT_OUTPUT, actualOutput);
        }

        [TestMethod]
        public void OutputResultTest()
        {
            //Use hash value to compare output files
            Processor.OutputResult(EXPECT_OUTPUT, ACTUAL_REPORT_ADDRESS);
            Assert.AreEqual(GetFileHash(EXPECT_REPORT_ADDRESS), GetFileHash(ACTUAL_REPORT_ADDRESS));
        }
    }
}
