﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace LogFileProcessor
{
    public static class Processor
    {
        public static void ReadLogFile(ref Dictionary<string, int> IP_Count, ref Dictionary<string, int> URL_Count, string path)
        {
            Regex regex = new Regex("^(([0-9]{1,3}\\.){3}[0-9]{1,3})" + //IP Address
                                    "\\s[a-zA-Z -]+\\s"+ // Separator
                                    "\\[[0-9]{2}/[a-zA-Z]+/[0-9]{4}(:[0-9]{2}){3}\\s\\+[0-9]{4}]\\s" + //Datetime
                                    "\"[a-zA-Z]+\\s" + //HTTP methods
                                    "(.+)" + // URL
                                    "\\sHTTP/[0-9.]+\"" + //content
                                    "\\s([0-9]+)" + //Response Code
                                    "\\s[0-9]+\\s\".+$" //Rest of content
                                    , RegexOptions.IgnoreCase);

            using (FileStream fs = File.Open(path, FileMode.Open, FileAccess.Read))
            using (BufferedStream bs = new BufferedStream(fs))
            using (StreamReader sr = new StreamReader(bs))
            {
                string lineRead;

                while ((lineRead = sr.ReadLine()) != null)
                {
                    var IP_fatched = regex.Match(lineRead).Groups[1].ToString().Trim();
                    var URL_fatched = regex.Match(lineRead).Groups[4].ToString().Split('?')[0].ToString().Trim(); //Only get url without parameters
                    var ResponseCode = regex.Match(lineRead).Groups[5].ToString().Trim();

                    if (!string.IsNullOrEmpty(IP_fatched))
                    {
                        if (IP_Count.ContainsKey(IP_fatched))
                            IP_Count[IP_fatched]++;         //Increase counter
                        else
                            IP_Count.Add(IP_fatched, 1);    //First time apprearance
                    }

                    if (!string.IsNullOrEmpty(URL_fatched) && ResponseCode.StartsWith("2")) //Regard response code '2xx' as valid URL in statistics
                    {
                        if (URL_Count.ContainsKey(URL_fatched))
                            URL_Count[URL_fatched]++;       //Increase counter
                        else
                            URL_Count.Add(URL_fatched, 1);  //First time apprearance
                    }
                }
            }
        }

        public static string ProcessLogFile(Dictionary<string, int> IP_Count, Dictionary<string, int> URL_Count, int num)
        {
            string resultOutput = "";
            var Most_Visited_URL = "";
            var Most_Active_IP = "";
            //Allow tied for Top count numbers 
            var URL_Top = new HashSet<int>(); 
            var IP_Top = new HashSet<int>();

            //Part1： Output Unique IP number
            resultOutput += "Number of Unique IP Address: " + IP_Count.Count.ToString();
            //Part2： Output Top Visited URLs in loop
            while (URL_Top.Count < num)
            {
                if (!string.IsNullOrEmpty(Most_Visited_URL))
                    URL_Count.Remove(Most_Visited_URL);

                if (URL_Count.Count == 0)
                    break;  //If no URL in Dictionary, skip loop

                Most_Visited_URL = URL_Count.Aggregate((x, y) => x.Value > y.Value ? x : y).Key;
                URL_Top.Add(URL_Count[Most_Visited_URL]);
                resultOutput += "$$Top " + URL_Top.Count + " Most Visited URL: " + Most_Visited_URL.ToString() + " Count: " + URL_Count[Most_Visited_URL].ToString();
            }
            //Part3： Output Top Active IPs in loop
            while (IP_Top.Count < num)
            {
                if (!string.IsNullOrEmpty(Most_Active_IP))
                    IP_Count.Remove(Most_Active_IP);

                if (IP_Count.Count == 0)
                    break;  //If no IP in Dictionary, skip loop

                Most_Active_IP = IP_Count.Aggregate((x, y) => x.Value > y.Value ? x : y).Key;
                IP_Top.Add(IP_Count[Most_Active_IP]);
                resultOutput += "$$Top " + IP_Top.Count + " Active IP Address: " + Most_Active_IP.ToString() + " Count: " + IP_Count[Most_Active_IP].ToString();
            }

            return resultOutput.Replace("$$", System.Environment.NewLine); ;
        }

        public static void OutputResult(string output, string path)
        {
            File.WriteAllText(path, string.Empty);
            Console.WriteLine(output);  //print out in Console

            using (FileStream fs = new FileStream(path, FileMode.Append, FileAccess.Write))
            using (StreamWriter sw = new StreamWriter(fs))
            {
                sw.WriteLine(output);   //print out in Report.txt
            }
        }
    }
}
