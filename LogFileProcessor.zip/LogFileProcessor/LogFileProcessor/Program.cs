﻿using System;
using System.Collections.Generic;
using System.Configuration;

namespace LogFileProcessor
{
    class Program
    {
        static void Main(string[] args)
        {
            //Get input/output address, Get top N number to output in report
            var LOG_ADDRESS = ConfigurationManager.AppSettings["Log_Address"].ToString();
            var OUTPUT_ADDRESS = ConfigurationManager.AppSettings["Report_Address"].ToString();
            var TOPNUMBER = int.Parse(ConfigurationManager.AppSettings["Get_Top_Num"].ToString());

            //Initiate Dictionary to hold fetched information
            Dictionary<string, int> IP_count = new Dictionary<string, int>();
            Dictionary<string, int> URL_count = new Dictionary<string, int>();

            //Process step1: Read log file into Dictionary
            Processor.ReadLogFile(ref IP_count, ref URL_count, LOG_ADDRESS);
            //Process step2: Generate output string
            var outputContent = Processor.ProcessLogFile(IP_count, URL_count, TOPNUMBER);
            //Process step3: Output string to report/console
            Processor.OutputResult(outputContent, OUTPUT_ADDRESS);
            Console.ReadLine();
        }
    }
}
