============================================
*** Welcome to LogFileProcessor solution ***
*** Author: Scott SHI
*** Time: 23 May 2021
============================================
This solution includes 2 parts:
1. LogFileProcessor
2. LogFileProcessor.UnitTests

Part 1: \LogFileProcessor
* This is a console application, input log file: "programming-task-example-data.log" is located in \LogFileProcessor\Files\InputLogFile\
* If user wants to point this application to other input files, please change the configuration in App.Config: 
  <add key="Log_Address" value="..\..\Files\InputLogFile\programming-task-example-data.log" />

* This console application will output a txt report: Report.txt after execution, which is located in \LogFileProcessor\Files\OutputReport\
* If user wants to output report to somewhere else, please change the configuration in App.Config: 
  <add key="Report_Address" value="..\..\Files\OutputReport\Report.txt" />

* This console application allow users to give a top N active IPs or requested URLs, the default number is top 3
* If user wants to change the top number, please change the configuration in App.Config: 
  <add key="Get_Top_Num" value="3" />

* @ Please Note: The top N records in report allow tied situation. All tied IP address or URLs will rank same and listed in result. 
  @ For instance, if IP1 and IP2 appears most frequently and both of them appear 10 times, then, the top 1 active IP address are IP1 and IP2.

* @ Please Note: The most visited URLs in result only includes success http response code: 2xx. 
  @ Because in real scenario, when user counts most visited/popular URLs, they only care valid/success URLs, rather than redirect URL or Error URLs

* @ Please Note: The same URL/resource with different http parameters are regarded as same URLs, so parameters in URLs are removed in output report

Part 2: \LogFileProcessor.UnitTests
* This is Unit Test project. All 3 methods in Processor.cs are tested and passed.

* 10 random lines from input log file are selected for testing. The testing log file, expected output report and actual output report are located:
  \LogFileProcessor\LogFileProcessor.UnitTests\TestData

============================================================================
*** The following functions are not realized but I think they are useful ***
============================================================================
1. When output most active IPs, the solution counts IPs appear most frequently in entire log file. If user wants to set a time scope (e.g. 1 week),
   then solution should be able to take advantage of "datetime" (e.g. [09/Jul/2018:15:48:20 +0200]) in log records. 
   Then, only counts the frequency within the given time scope
2. Currently, the soltion outputs all tied rankings into report. HashSet is used to hold the number. (Please see Processor.cs line 60, 61)
   If user wants exactly top 3 records to be printed out, then List will be used.

